﻿namespace MoedaEstudantil.DTOs
{
    public class EmpresaDTO : PessoaDTO
    {
    }
}
