﻿using MoedaEstudantil.Enums;
using System.ComponentModel.DataAnnotations;

namespace MoedaEstudantil.Entities
{
    public class Transacao
    {
        [Key]
        public required Guid Id { get; set; }
        public required Guid AlunoId { get; set; }
        public Guid ProfessorId { get; set; }
        public Guid VantagemId { get; set; }
        public required TipoTransacao TipoTransacao { get; set; } 
        public required decimal Valor { get; set; }
        public required DateTime Data { get; set; }
        public string Mensagem { get; set; }
    } 

}
