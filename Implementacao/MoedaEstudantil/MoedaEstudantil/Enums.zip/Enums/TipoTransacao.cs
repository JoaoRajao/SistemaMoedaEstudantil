﻿namespace MoedaEstudantil.Enums
{
    public enum TipoTransacao
    {
        ENVIO,
        RESGATE,
        TROCA
    }
}
