﻿namespace MoedaEstudantil.DTOs
{
    public class PessoaDTO
    {
        public required string Nome { get; set; }
        public required string Senha { get; set; }
        public required string Documento { get; set; }
        public required string Email { get; set; }
    }
}
